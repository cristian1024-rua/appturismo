import 'package:appturismo/repositories/auth_repository.dart';
import 'package:appwrite/appwrite.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';

class AppwriteService {
  late final Client client;
  late final Account account;
  late final Databases databases;
  late final Storage storage;

  AppwriteService() {
    client = Client()
        .setEndpoint(dotenv.env['APPWRITE_ENDPOINT'] ?? '')
        .setProject(dotenv.env['APPWRITE_PROJECT_ID'] ?? '')
        .setSelfSigned(status: false);

    account = Account(client);
    databases = Databases(client);
    storage = Storage(client);
  }

  AuthRepository get authRepository =>
      AuthRepository(account, databases, client);
}
