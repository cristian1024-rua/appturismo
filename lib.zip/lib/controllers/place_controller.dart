import 'package:appturismo/model/place_model.dart';
import 'package:appwrite/appwrite.dart';
import 'package:get/get.dart';
import 'package:appwrite/models.dart';
import 'package:appturismo/repositories/place_repository.dart';
import 'package:geolocator/geolocator.dart';

class PlaceController extends GetxController {
  final PlaceRepository _placeRepository;
  RxList<Document> places = <Document>[].obs;
  RxBool isLoading = false.obs;
  RxString errorMessage = ''.obs;

  PlaceController(this._placeRepository);

  @override
  void onInit() {
    super.onInit();
    fetchPlaces(); // Carga inicial de lugares
  }

  // ¡Asegúrate de que la firma de este método sea EXACTAMENTE esta!
  Future<void> fetchPlaces({
    double? userLat,
    double? userLon,
    String? searchQuery,
  }) async {
    isLoading.value = true;
    errorMessage.value = '';
    try {
      final fetchedPlaces = await _placeRepository.getPlaces(
        userLat: userLat,
        userLon: userLon,
        searchQuery: searchQuery,
      );

      // Opcional: Ordenar por distancia si se usó la ubicación
      if (userLat != null && userLon != null) {
        fetchedPlaces.sort((a, b) {
          double latA = a.data['latitude'] as double? ?? 0.0;
          double lonA = a.data['longitude'] as double? ?? 0.0;
          double latB = b.data['latitude'] as double? ?? 0.0;
          double lonB = b.data['longitude'] as double? ?? 0.0;

          double distA = Geolocator.distanceBetween(
            userLat,
            userLon,
            latA,
            lonA,
          );
          double distB = Geolocator.distanceBetween(
            userLat,
            userLon,
            latB,
            lonB,
          );
          return distA.compareTo(distB);
        });
      }
      places.assignAll(fetchedPlaces as Iterable<Document>);
    } on AppwriteException catch (e) {
      print('PlaceController: Error fetching places: ${e.message}');
      errorMessage.value = 'Error de Appwrite: ${e.message}';
    } catch (e) {
      print('PlaceController: Unknown error fetching places: $e');
      errorMessage.value = 'Error desconocido: ${e.toString()}';
    } finally {
      isLoading.value = false;
    }
  }

  void addPlace(Place newPlace) {}
}
