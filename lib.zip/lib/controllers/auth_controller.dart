// lib/controllers/auth_controller.dart
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:appwrite/appwrite.dart';
import 'package:appwrite/models.dart' as models;
import 'package:appturismo/repositories/auth_repository.dart';

class AuthController extends GetxController {
  final AuthRepository _authRepository;

  // Observables para el estado de la UI
  RxBool isLoading = false.obs;
  RxBool isAuthenticated = false.obs;
  Rx<models.User?> currentUser = Rx<models.User?>(
    null,
  ); // Almacena el usuario autenticado

  AuthController(this._authRepository);

  @override
  void onInit() {
    super.onInit();
    checkLoginStatus(); // Verificar estado al iniciar el controlador
  }

  Future<void> checkLoginStatus() async {
    isLoading.value = true;
    try {
      final user = await _authRepository.getCurrentUser();
      if (user != null && user.status) {
        // Asumiendo que 'status' indica que la cuenta está activa/válida
        currentUser.value = user;
        isAuthenticated.value = true;
        print('AuthController: Usuario autenticado: ${user.email}');
        Get.offAllNamed('/places'); // Redirigir si ya está logueado
      } else {
        currentUser.value = null;
        isAuthenticated.value = false;
        print('AuthController: Usuario no autenticado.');
      }
    } catch (e) {
      currentUser.value = null;
      isAuthenticated.value = false;
      print('AuthController: Error al verificar estado de login: $e');
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> login(String email, String password) async {
    isLoading.value = true;
    try {
      print(
        'DEBUG_LOGIN: Intentando login con Email: "$email" y Contraseña: "$password"',
      );
      final session = await _authRepository.login(
        email: email,
        password: password,
      );
      if (session.userId.isNotEmpty) {
        // Si la sesión tiene un ID, fue exitoso
        await checkLoginStatus(); // Vuelve a verificar para obtener el objeto User completo
        Get.offAllNamed('/places'); // Redirige a la pantalla principal
        Get.snackbar(
          'Éxito',
          'Inicio de sesión exitoso',
          backgroundColor: Colors.green.withOpacity(0.7),
          colorText: Colors.white,
        );
      } else {
        Get.snackbar(
          'Error de Login',
          'Credenciales inválidas.',
          backgroundColor: Colors.red.withOpacity(0.7),
          colorText: Colors.white,
        );
      }
    } on AppwriteException catch (e) {
      print('AuthController: Error en login: ${e.message}, (${e.code})');
      String errorMessage = 'Error al iniciar sesión.';
      if (e.code == 401 || e.code == 400) {
        // 401 Unauthorized, 400 Bad Request (comúnmente por credenciales incorrectas)
        errorMessage = 'Email o contraseña incorrectos.';
      } else if (e.code == 429) {
        // Too Many Requests
        errorMessage = 'Demasiados intentos. Por favor, inténtalo más tarde.';
      }
      Get.snackbar(
        'Error de Login',
        errorMessage,
        backgroundColor: Colors.red.withOpacity(0.7),
        colorText: Colors.white,
      );
    } catch (e) {
      print('AuthController: Error inesperado en login: $e');
      Get.snackbar(
        'Error',
        'Ha ocurrido un error inesperado. Inténtalo de nuevo.',
        backgroundColor: Colors.red.withOpacity(0.7),
        colorText: Colors.white,
      );
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> register(String email, String password, String name) async {
    isLoading.value = true;
    try {
      print(
        'DEBUG_REGISTER: Intentando registro con Email: "$email", Nombre: "$name", y Contraseña: "$password"',
      );
      final user = await _authRepository.register(
        email: email,
        password: password,
        name: name,
      );
      if (user.$id.isNotEmpty) {
        Get.snackbar(
          'Éxito',
          'Registro exitoso. ¡Inicia sesión!',
          backgroundColor: Colors.green.withOpacity(0.7),
          colorText: Colors.white,
        );
        Get.offAllNamed('/login'); // Redirige a la pantalla de login
      } else {
        Get.snackbar(
          'Error de Registro',
          'No se pudo completar el registro.',
          backgroundColor: Colors.red.withOpacity(0.7),
          colorText: Colors.white,
        );
      }
    } on AppwriteException catch (e) {
      print('AuthController: Error en registro: ${e.message}, (${e.code})');
      String errorMessage = 'Error al registrar usuario.';
      if (e.code == 409) {
        // Conflict (user_already_exists)
        errorMessage = 'Este email ya está registrado.';
      } else if (e.code == 400) {
        // Bad Request (password too weak, invalid email format etc.)
        errorMessage =
            e.message ?? 'Datos de registro inválidos (ej. contraseña débil).';
      }
      Get.snackbar(
        'Error de Registro',
        errorMessage,
        backgroundColor: Colors.red.withOpacity(0.7),
        colorText: Colors.white,
      );
    } catch (e) {
      print('AuthController: Error inesperado en registro: $e');
      Get.snackbar(
        'Error',
        'Ha ocurrido un error inesperado. Inténtalo de nuevo.',
        backgroundColor: Colors.red.withOpacity(0.7),
        colorText: Colors.white,
      );
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> logout() async {
    isLoading.value = true;
    try {
      await _authRepository.logout();
      isAuthenticated.value = false;
      currentUser.value = null;
      Get.offAllNamed('/login');
      Get.snackbar(
        'Sesión cerrada',
        'Has cerrado sesión correctamente.',
        backgroundColor: Colors.green.withOpacity(0.7),
        colorText: Colors.white,
      );
    } on AppwriteException catch (e) {
      print('AuthController: Error al cerrar sesión: ${e.message}');
      Get.snackbar(
        'Error',
        'No se pudo cerrar la sesión.',
        backgroundColor: Colors.red.withOpacity(0.7),
        colorText: Colors.white,
      );
    } finally {
      isLoading.value = false;
    }
  }
}
