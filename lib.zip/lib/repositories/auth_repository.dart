import 'package:appwrite/appwrite.dart';
import 'package:appwrite/models.dart' as models;

class AuthRepository {
  final Account account;
  final Databases databases;
  final Client client;

  static const String DATABASE_ID = '6819351d00288e3d0bf7';
  static const String USERS_COLLECTION_ID = '681935ea0021949d4a7f';
  static const String ENDPOINT = 'https://fra.cloud.appwrite.io/v1';

  AuthRepository(this.account, this.databases, this.client);

  /// Inicia sesión con email y contraseña
  Future<models.Session> login({
    required String email,
    required String password,
  }) async {
    try {
      print('AuthRepository: Iniciando sesión para: $email');

      // Creamos el userId a partir del email
      String userId = email.split('@')[0].toLowerCase();
      userId = userId.replaceAll(RegExp(r'[^a-z0-9]'), '_');

      print('AuthRepository: Usando userId: $userId');

      // Usar createSession con userId y password
      final session = await account.createSession(
        userId: userId,
        secret: password,
      );

      print('AuthRepository: Sesión creada exitosamente - ID: ${session.$id}');
      return session;
    } on AppwriteException catch (e) {
      print(
        'AuthRepository: Error de AppWrite en login: ${e.message} (Code: ${e.code})',
      );
      if (e.code == 401) {
        throw Exception('Credenciales inválidas');
      } else if (e.code == 429) {
        throw Exception('Demasiados intentos. Por favor, espera unos minutos.');
      } else if (e.code == 400) {
        throw Exception('Error de formato en las credenciales');
      }
      rethrow;
    } catch (e) {
      print('AuthRepository: Error inesperado en login: $e');
      throw Exception('Error al iniciar sesión: $e');
    }
  }

  /// Registra un nuevo usuario
  Future<models.User> register({
    required String email,
    required String password,
    required String name,
  }) async {
    try {
      print('AuthRepository: Registrando nuevo usuario: $email');

      // Crear userId a partir del email
      String userId = email.split('@')[0].toLowerCase();
      userId = userId.replaceAll(RegExp(r'[^a-z0-9]'), '_');

      print('AuthRepository: Usando userId para registro: $userId');

      final user = await account.create(
        userId: userId,
        email: email,
        password: password,
        name: name,
      );

      print(
        'AuthRepository: Usuario registrado exitosamente - ID: ${user.$id}',
      );

      // Crear sesión después del registro
      try {
        await account.createSession(userId: userId, secret: password);
        print('AuthRepository: Sesión inicial creada para el nuevo usuario');
      } catch (e) {
        print('AuthRepository: No se pudo crear la sesión inicial: $e');
      }

      return user;
    } on AppwriteException catch (e) {
      print(
        'AuthRepository: Error de AppWrite en registro: ${e.message} (Code: ${e.code})',
      );
      if (e.code == 409) {
        throw Exception('El email ya está registrado');
      } else if (e.code == 400) {
        throw Exception('Datos inválidos: ${e.message}');
      }
      rethrow;
    } catch (e) {
      print('AuthRepository: Error inesperado en registro: $e');
      throw Exception('Error al registrar usuario: $e');
    }
  }

  /// Obtiene el usuario actualmente autenticado
  Future<models.User?> getCurrentUser() async {
    try {
      final user = await account.get();
      print(
        'AuthRepository: Usuario actual obtenido exitosamente: ${user.email}',
      );
      return user;
    } on AppwriteException catch (e) {
      print(
        'AuthRepository: Error al obtener usuario actual: ${e.message} (Code: ${e.code})',
      );
      if (e.code == 401) {
        return null;
      }
      rethrow;
    } catch (e) {
      print('AuthRepository: Error inesperado al obtener usuario actual: $e');
      rethrow;
    }
  }

  /// Cierra la sesión actual
  Future<void> logout() async {
    try {
      print('AuthRepository: Cerrando sesión actual');
      await account.deleteSession(sessionId: 'current');
      print('AuthRepository: Sesión cerrada exitosamente');
    } on AppwriteException catch (e) {
      print(
        'AuthRepository: Error de AppWrite al cerrar sesión: ${e.message} (Code: ${e.code})',
      );
      if (e.code == 401) {
        return;
      }
      rethrow;
    } catch (e) {
      print('AuthRepository: Error inesperado al cerrar sesión: $e');
      throw Exception('Error al cerrar sesión: $e');
    }
  }

  /// Actualiza el nombre del usuario
  Future<models.User> updateName(String name) async {
    try {
      print('AuthRepository: Actualizando nombre de usuario a: $name');
      final user = await account.updateName(name: name);
      print('AuthRepository: Nombre actualizado exitosamente');
      return user;
    } on AppwriteException catch (e) {
      print(
        'AuthRepository: Error de AppWrite al actualizar nombre: ${e.message} (Code: ${e.code})',
      );
      rethrow;
    } catch (e) {
      print('AuthRepository: Error inesperado al actualizar nombre: $e');
      throw Exception('Error al actualizar nombre: $e');
    }
  }

  /// Actualiza el email del usuario
  Future<models.User> updateEmail({
    required String email,
    required String password,
  }) async {
    try {
      print('AuthRepository: Actualizando email a: $email');
      final user = await account.updateEmail(email: email, password: password);
      print('AuthRepository: Email actualizado exitosamente');
      return user;
    } on AppwriteException catch (e) {
      print(
        'AuthRepository: Error de AppWrite al actualizar email: ${e.message} (Code: ${e.code})',
      );
      if (e.code == 401) {
        throw Exception('Contraseña incorrecta');
      } else if (e.code == 409) {
        throw Exception('El email ya está en uso');
      }
      rethrow;
    } catch (e) {
      print('AuthRepository: Error inesperado al actualizar email: $e');
      throw Exception('Error al actualizar email: $e');
    }
  }

  /// Actualiza la contraseña del usuario
  Future<void> updatePassword({
    required String oldPassword,
    required String newPassword,
  }) async {
    try {
      print('AuthRepository: Actualizando contraseña');
      await account.updatePassword(
        password: newPassword,
        oldPassword: oldPassword,
      );
      print('AuthRepository: Contraseña actualizada exitosamente');
    } on AppwriteException catch (e) {
      print(
        'AuthRepository: Error de AppWrite al actualizar contraseña: ${e.message} (Code: ${e.code})',
      );
      if (e.code == 401) {
        throw Exception('Contraseña actual incorrecta');
      }
      rethrow;
    } catch (e) {
      print('AuthRepository: Error inesperado al actualizar contraseña: $e');
      throw Exception('Error al actualizar contraseña: $e');
    }
  }

  /// Envía un email de recuperación de contraseña
  Future<models.Token> resetPassword(String email) async {
    try {
      print('AuthRepository: Enviando email de recuperación a: $email');
      final token = await account.createRecovery(
        email: email,
        url:
            'https://appturismo.com/reset-password', // Ajusta esta URL según tu configuración
      );
      print('AuthRepository: Email de recuperación enviado exitosamente');
      return token;
    } on AppwriteException catch (e) {
      print(
        'AuthRepository: Error de AppWrite al enviar recuperación: ${e.message} (Code: ${e.code})',
      );
      if (e.code == 404) {
        throw Exception('Email no encontrado');
      }
      rethrow;
    } catch (e) {
      print('AuthRepository: Error inesperado al enviar recuperación: $e');
      throw Exception('Error al enviar email de recuperación: $e');
    }
  }

  /// Verifica el email del usuario
  Future<models.Token> verifyEmail() async {
    try {
      print('AuthRepository: Enviando email de verificación');
      final token = await account.createVerification(
        url:
            'https://appturismo.com/verify-email', // Ajusta esta URL según tu configuración
      );
      print('AuthRepository: Email de verificación enviado exitosamente');
      return token;
    } on AppwriteException catch (e) {
      print(
        'AuthRepository: Error de AppWrite al enviar verificación: ${e.message} (Code: ${e.code})',
      );
      rethrow;
    } catch (e) {
      print('AuthRepository: Error inesperado al enviar verificación: $e');
      throw Exception('Error al enviar email de verificación: $e');
    }
  }

  /// Verifica si hay una sesión activa
  Future<bool> isLoggedIn() async {
    try {
      final user = await getCurrentUser();
      return user != null;
    } catch (e) {
      return false;
    }
  }

  /// Obtiene todas las sesiones activas
  Future<List<models.Session>> getSessions() async {
    try {
      print('AuthRepository: Obteniendo sesiones activas');
      final sessions = await account.listSessions();
      print('AuthRepository: ${sessions.total} sesiones encontradas');
      return sessions.sessions;
    } on AppwriteException catch (e) {
      print(
        'AuthRepository: Error al obtener sesiones: ${e.message} (Code: ${e.code})',
      );
      rethrow;
    } catch (e) {
      print('AuthRepository: Error inesperado al obtener sesiones: $e');
      throw Exception('Error al obtener sesiones: $e');
    }
  }

  /// Obtiene la sesión actual
  Future<models.Session?> getCurrentSession() async {
    try {
      print('AuthRepository: Obteniendo sesión actual');
      final session = await account.getSession(sessionId: 'current');
      print('AuthRepository: Sesión actual obtenida exitosamente');
      return session;
    } on AppwriteException catch (e) {
      print(
        'AuthRepository: Error al obtener sesión actual: ${e.message} (Code: ${e.code})',
      );
      if (e.code == 401) {
        return null;
      }
      rethrow;
    } catch (e) {
      print('AuthRepository: Error inesperado al obtener sesión actual: $e');
      throw Exception('Error al obtener sesión actual: $e');
    }
  }
}
