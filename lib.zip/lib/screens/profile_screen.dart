// Importa User de Appwrite si no lo está
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:appturismo/controllers/auth_controller.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final authCtrl = Get.find<AuthController>();

    // Usar Obx para reaccionar a los cambios en currentUser
    return Obx(() {
      final user = authCtrl.currentUser.value; // Usar currentUser.value

      return Scaffold(
        appBar: AppBar(title: const Text('Perfil')),
        body:
            user == null
                ? const Center(
                  child: Text('No hay datos de usuario. Inicia sesión.'),
                )
                : Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    children: [
                      CircleAvatar(
                        radius: 40,
                        // Appwrite User tiene 'name', no 'username' por defecto.
                        // Usar el primer carácter del email si el nombre no está disponible.
                        child: Text(
                          user.name?.isNotEmpty == true
                              ? user.name![0].toUpperCase()
                              : user.email[0].toUpperCase(),
                        ),
                      ),
                      const SizedBox(height: 12),
                      Text(
                        user.name?.isNotEmpty == true
                            ? user.name!
                            : 'Nombre no disponible', // Mostrar el nombre o un placeholder
                        style: const TextStyle(fontSize: 20),
                      ),
                      const SizedBox(height: 8),
                      Text(user.email),
                      const Spacer(),
                      ElevatedButton(
                        onPressed: () => authCtrl.logout(),
                        child: const Text('Cerrar Sesión'),
                      ),
                    ],
                  ),
                ),
      );
    });
  }
}

// ELIMINAR ESTAS EXTENSIONES, ESTÁN CAUSANDO PROBLEMAS
// extension on RxInterface<Object?>? {
//   get value => null;
// }

// extension on User {}
