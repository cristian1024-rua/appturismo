// lib/screens/places_screen.dart
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:geolocator/geolocator.dart'; // Importante para la ubicación y cálculo de distancia
// ¡DESCOMENTADA! Para el tipo Document

import 'package:appturismo/controllers/auth_controller.dart';
import 'package:appturismo/controllers/location_controller.dart';
import 'package:appturismo/controllers/place_controller.dart';
import 'package:appturismo/screens/add_place_screen.dart'; // Asegúrate de que esta pantalla exista

class PlacesScreen extends StatefulWidget {
  const PlacesScreen({super.key});

  @override
  State<PlacesScreen> createState() => _PlacesScreenState();
}

class _PlacesScreenState extends State<PlacesScreen> {
  // Obtener las instancias de los controladores inyectados por GetX
  final LocationController _locationController = Get.find<LocationController>();
  final PlaceController _placeController = Get.find<PlaceController>();
  final AuthController _authController = Get.find<AuthController>();

  final TextEditingController _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    // Suscribirse a los cambios de la ubicación.
    // Cuando _locationController.currentLocation tenga un valor, o cambie,
    // se llama a fetchPlaces para cargar los lugares cercanos.
    ever(_locationController.currentLocation, (Position? position) {
      if (position != null) {
        _placeController.fetchPlaces(
          userLat: position.latitude,
          userLon: position.longitude,
          searchQuery: _searchController.text, // Mantiene el filtro de búsqueda
        );
      } else if (!_locationController.isLoading.value &&
          _locationController.errorMessage.value.isEmpty) {
        // Si no hay ubicación (pero tampoco error y no está cargando),
        // intenta cargar lugares sin el filtro de proximidad.
        // Aquí no necesitas especificar userLat: null, userLon: null porque ya son opcionales
        _placeController.fetchPlaces(searchQuery: _searchController.text);
      }
    });

    // Iniciar la carga de lugares. Esto podría suceder antes de que la ubicación esté lista.
    // Aquí tampoco necesitas especificar userLat: null, userLon: null
    _placeController.fetchPlaces(searchQuery: _searchController.text);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Lugares Turísticos'),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () {
              _authController.logout();
            },
          ),
          // Manteniendo tus botones adicionales, asegúrate que las rutas existan en main.dart
          IconButton(
            icon: const Icon(Icons.favorite),
            onPressed: () {
              // Verifica si la ruta existe o si la pantalla está creada
              Get.toNamed(
                '/favorites',
              ); // Asegúrate de tener esta ruta definida
            },
          ),
          IconButton(
            icon: const Icon(Icons.person),
            onPressed: () {
              // Verifica si la ruta existe o si la pantalla está creada
              Get.toNamed('/profile'); // Asegúrate de tener esta ruta definida
            },
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: 'Buscar lugares...',
                suffixIcon: IconButton(
                  icon: const Icon(Icons.search),
                  onPressed: () {
                    // Acceder a la ubicación actual solo si no es nula
                    final currentPosition =
                        _locationController.currentLocation.value;
                    _placeController.fetchPlaces(
                      userLat:
                          currentPosition!
                              .latitude, // Uso del operador ?. para acceso seguro
                      userLon:
                          currentPosition
                              .longitude, // Uso del operador ?. para acceso seguro
                      searchQuery: _searchController.text,
                    );
                  },
                ),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10.0),
                ),
              ),
              onSubmitted: (value) {
                // Acceder a la ubicación actual solo si no es nula
                final currentPosition =
                    _locationController.currentLocation.value;
                _placeController.fetchPlaces(
                  userLat:
                      currentPosition!
                          .latitude, // Uso del operador ?. para acceso seguro
                  userLon:
                      currentPosition
                          .longitude, // Uso del operador ?. para acceso seguro
                  searchQuery: value,
                );
              },
            ),
          ),
          // Mostrar el estado de la ubicación
          Obx(() {
            if (_locationController.isLoading.value) {
              return const LinearProgressIndicator();
            }
            if (_locationController.errorMessage.value.isNotEmpty) {
              return Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text(
                  'Error de ubicación: ${_locationController.errorMessage.value}',
                  style: const TextStyle(color: Colors.red),
                ),
              );
            }
            return const SizedBox.shrink();
          }),
          // Mostrar el estado de carga y los lugares
          Expanded(
            child: Obx(() {
              if (_placeController.isLoading.value) {
                return const Center(child: CircularProgressIndicator());
              }
              if (_placeController.errorMessage.value.isNotEmpty) {
                return Center(
                  child: Text(
                    'Error al cargar lugares: ${_placeController.errorMessage.value}',
                    style: const TextStyle(color: Colors.red),
                  ),
                );
              }
              if (_placeController.places.isEmpty) {
                return const Center(
                  child: Text('No se encontraron lugares turísticos.'),
                );
              }
              return ListView.builder(
                itemCount: _placeController.places.length,
                itemBuilder: (context, index) {
                  final place = _placeController.places[index];
                  final String title =
                      place.data['title'] as String? ?? 'Sin Título';
                  final String description =
                      place.data['description'] as String? ?? 'Sin Descripción';
                  final String imageUrl =
                      place.data['imageUrl'] as String? ?? '';
                  final double? lat = place.data['latitude'] as double?;
                  final double? lon = place.data['longitude'] as double?;

                  String distanceText = '';
                  // Calcular y mostrar la distancia si la ubicación del usuario está disponible
                  if (_locationController.currentLocation.value != null &&
                      lat != null &&
                      lon != null) {
                    double distanceInMeters = Geolocator.distanceBetween(
                      _locationController
                          .currentLocation
                          .value!
                          .latitude, // Aquí es seguro usar ! porque ya se comprobó el null
                      _locationController
                          .currentLocation
                          .value!
                          .longitude, // Aquí es seguro usar ! porque ya se comprobó el null
                      lat,
                      lon,
                    );
                    distanceText =
                        ' (${(distanceInMeters / 1000).toStringAsFixed(1)} km)';
                  }

                  return Card(
                    margin: const EdgeInsets.all(8.0),
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          if (imageUrl.isNotEmpty)
                            Image.network(
                              imageUrl,
                              height: 150,
                              width: double.infinity,
                              fit: BoxFit.cover,
                              errorBuilder:
                                  (context, error, stackTrace) => const Center(
                                    child: Icon(
                                      Icons.image_not_supported,
                                      size: 50,
                                    ),
                                  ),
                            ),
                          const SizedBox(height: 8),
                          Text(
                            '$title$distanceText',
                            style: const TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(description),
                        ],
                      ),
                    ),
                  );
                },
              );
            }),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          // Navega directamente a la pantalla de añadir lugar
          Get.to(
            () => AddPlaceScreen(),
          ); // Agregué 'const' ya que AddPlaceScreen es un StatelessWidget
        },
        child: const Icon(Icons.add),
      ),
    );
  }
}
