// lib/screens/splash_screen.dart
import 'package:flutter/material.dart';
// import 'package:appturismo/controllers/auth_controller.dart'; // No es necesario si no usas _authController aquí

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  // Ya no necesitamos _authController ni ninguna lógica aquí.
  // final AuthController _authController = Get.find<AuthController>();

  @override
  void initState() {
    super.initState();
    // No hay lógica de navegación aquí.
    // La navegación la manejará el Obx en main.dart
  }

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircularProgressIndicator(),
            SizedBox(height: 20),
            Text('Cargando...', style: TextStyle(fontSize: 18)),
          ],
        ),
      ),
    );
  }
}
