// lib/main.dart
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:appwrite/appwrite.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart'; // <--- ¡AQUÍ LA CORRECCIÓN!
import 'package:get_storage/get_storage.dart';

// Controladores
import 'package:appturismo/controllers/auth_controller.dart';
import 'package:appturismo/controllers/user_controller.dart';
import 'package:appturismo/controllers/location_controller.dart';
import 'package:appturismo/controllers/place_controller.dart';
import 'package:appturismo/controllers/favorites_controller.dart';

// Repositorios
import 'package:appturismo/repositories/auth_repository.dart';
import 'package:appturismo/repositories/user_repository.dart';
import 'package:appturismo/repositories/place_repository.dart';
import 'package:appturismo/repositories/storage_repository.dart';
import 'package:appturismo/repositories/favorites_repository.dart';

// Pantallas
import 'package:appturismo/screens/splash_screen.dart';
import 'package:appturismo/screens/login_screen.dart';
import 'package:appturismo/screens/register_screen.dart';
import 'package:appturismo/screens/profile_screen.dart';
import 'package:appturismo/screens/favorites_screen.dart';
import 'package:appturismo/screens/map_screen.dart';
import 'package:appturismo/screens/home_screen.dart';
import 'package:appturismo/screens/places_screen.dart';
import 'package:appturismo/screens/add_place_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  print('main: WidgetsFlutterBinding inicializado.');

  try {
    await dotenv.load(fileName: ".env");
    print('main: Variables de entorno (.env) cargadas correctamente.');
  } catch (e) {
    print('main: ERROR CRÍTICO al cargar .env: $e');
  }

  await GetStorage.init();

  print('main: Inicializando Cliente Appwrite...');
  Client client = Client()
      .setEndpoint(dotenv.env['APPWRITE_ENDPOINT']!)
      .setProject(dotenv.env['APPWRITE_PROJECT_ID']!)
      .setSelfSigned(status: true); // Mantener en true para desarrollo local

  Account account = Account(client);
  Databases databases = Databases(client);
  Storage storage = Storage(client);

  String databaseId = dotenv.env['APPWRITE_DATABASE_ID']!;
  String usersCollectionId = dotenv.env['APPWRITE_USERS_COLLECTION_ID']!;
  String placesCollectionId = dotenv.env['APPWRITE_PLACES_COLLECTION_ID']!;
  String bucketId = dotenv.env['APPWRITE_BUCKET_ID']!;
  String favoritesCollectionId =
      dotenv.env['APPWRITE_FAVORITES_COLLECTION_ID']!; // YA ESTÁ EN PLURAL

  print('main: Registrando repositorios...');
  Get.put(AuthRepository(account, databases, client));
  Get.put(
    UserRepository(
      databases,
      databaseId: databaseId,
      usersCollectionId: usersCollectionId,
    ),
  );
  Get.put(
    PlaceRepository(
      databases,
      databaseId: databaseId,
      placesCollectionId: placesCollectionId,
    ),
  );
  Get.put(StorageRepository(storage, bucketId: bucketId));
  Get.put(
    FavoritesRepository(
      databases,
      databaseId: databaseId,
      favoritesCollectionId: favoritesCollectionId,
    ),
  );

  print('main: Registrando controladores...');
  Get.put(AuthController(Get.find<AuthRepository>()));
  Get.put(UserController(repository: Get.find<UserRepository>()));
  Get.put(LocationController());
  Get.put(PlaceController(Get.find<PlaceRepository>()));
  Get.put(FavoritesController(Get.find<FavoritesRepository>()));

  print('main: Iniciando runApp...');
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    final AuthController authController = Get.find<AuthController>();

    return GetMaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Turismo App',
      theme: ThemeData(
        primarySwatch: Colors.teal,
        brightness: Brightness.light,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      darkTheme: ThemeData(
        primarySwatch: Colors.teal,
        brightness: Brightness.dark,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: Obx(() {
        if (authController.isLoading.value) {
          return const SplashScreen();
        } else if (authController.isAuthenticated.value) {
          return const PlacesScreen();
        } else {
          return const LoginScreen();
        }
      }),

      getPages: [
        GetPage(name: '/splash', page: () => SplashScreen()),
        GetPage(name: '/login', page: () => const LoginScreen()),
        GetPage(name: '/register', page: () => const RegisterScreen()),
        GetPage(name: '/home', page: () => const HomeScreen()),
        GetPage(name: '/places', page: () => const PlacesScreen()),
        GetPage(name: '/add', page: () => AddPlaceScreen()),
        GetPage(name: '/map', page: () => MapScreen()),
        GetPage(name: '/favorites', page: () => FavoritesScreen()),
        GetPage(name: '/profile', page: () => const ProfileScreen()),
        GetPage(name: '/users-management', page: () => const HomeScreen()),
      ],
    );
  }
}
